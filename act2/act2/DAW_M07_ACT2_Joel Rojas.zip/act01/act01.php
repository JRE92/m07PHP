<html>

<body>
    <?php
    #Joel Rojas Espinoza
    echo "ACT 1 - ARRAY ASOCIATIVO<br><br>";

    $notas['laura'] = 9;
    $notas['xavier'] = 8;
    $notas['media'] = 6.5;

    echo "<h1>La nota más alta es la de Laura con un: ".$notas['laura']."</h1>";
    echo "<h1>La nota más baja es la de Xavier con un: ".$notas['xavier']."</h1>";
    echo "<h1>La nota media de la clase es: ".$notas['media']."</h1>";

    
    ?>
</body>

</html>